export interface LoggedinUser {
    access_token: string,
}