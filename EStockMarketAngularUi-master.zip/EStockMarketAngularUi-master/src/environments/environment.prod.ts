export const environment = {
  production: true,
  apiUrlCompany: "https://companyapitest.azurewebsites.net",  
  apiUrlStock: "https://stocskapitest.azurewebsites.net"
};
